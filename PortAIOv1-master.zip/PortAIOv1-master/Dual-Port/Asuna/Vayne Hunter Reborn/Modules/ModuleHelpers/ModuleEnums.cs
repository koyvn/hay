﻿ namespace VayneHunter_Reborn.Modules.ModuleHelpers
{
    enum ModuleType
    {
        OnUpdate, OnAfterAA, Other
    }
}
